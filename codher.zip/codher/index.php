<html>
<head>
	<script>
    
	</script>
	<style>
	#gotovotepage{
		width:150px;
		opacity:0.4;
		height:100px;
		
		margin-left:43%;
		margin-top: 20px;
	}
	#gotovotepage:hover{
		opacity:1;
		width:155px;
		height:105px;
	}
	#homepagepic{
		 width:40% ;
		 height:50%;
		 margin-right: 20px;
		 margin-left: 450px;
		 margin-top: 50px;

		 
			vertical-align: middle;
	}
	body{
		background-image:url('images/dark-wood-texture.jpg');

	}
	</style>
<body>
	<?php include('pagetop.php');?>
	<img src="images/homepagepic.jpg" id="homepagepic">
	<a href="vote.php"><input type="image" id="gotovotepage" onclick="gotovotepage()" src="images/gotovotepage.jpg"/>
	</a>
</body>
</html>
