<?php
// AJAX CALLS THIS LOGIN CODE TO EXECUTE
if(isset($_POST["n"])){
	// CONNECT TO THE DATABASE
	include_once("php_includes/db_conx.php");
	// GATHER THE POSTED DATA INTO LOCAL VARIABLES AND SANITIZE
	$n = mysqli_real_escape_string($db_conx, $_POST['n']);
	$p = base64_encode($_POST['p']);
	// FORM DATA ERROR HANDLING
	if($n == "" || $p == ""){
		echo "login_failed";
        exit();
	} else {
	// END FORM DATA ERROR HANDLING
		$sql = "SELECT * FROM members WHERE name='$n'";
        $query = mysqli_query($db_conx, $sql);
        while ($row = mysqli_fetch_array(query, MYSQLI_ASSOC)) {
		$db_username = $row["name"];
        $db_pass_str = $row["password"];
		}
		if($p != $db_pass_str){
			echo "password_wrong";
            exit();
		}
	}
	exit();
}
?>
	
<html>
<head>
<title>member login</title>
<style>
		#header{
			height:200px;
			background: #000 url('images/background.jpg') repeat-y
				scroll left top;
			text-align: center;
		}
		#header div{
			height:300px;
			width:930px;
			background: transparent url('images/overlay.png') no-repeat
				scroll left top;

		}
		#header h1{
			padding-top: 100px;
			color:white;
			font-family: 'Lucida Console',monospace;

		}
		#nav{
			height:30px;
		}
		#body{
			background-color: #e74c3c;
			width:936px;
			height:500px;
		}
		form{
			padding-left:20%;
			padding-top:20%;
			background-color: green;
			center-align;
			width:300px;
			height:300px;
		}
		h3{
			text-align:center;
			color:white;
			font-family: 'Lucida Console',monospace;

		}
			
		
		body{
			background-color: black;
		}
		#wrapper{
			margin:0 auto;
			width:920px;
		}
		#inputArea
		{
			font-family: Arial, Sans-Serif;
			font-size: 13px;
			background-color: #d6e5f4;
			padding: 10px;
		}
		#inputArea input, #inputArea textarea
		{
			text-align:center;
			font-family: Arial, Sans-Serif;
			font-size: 13px;
			margin-bottom: 5px;
			display: block;
			padding: 4px;
			width: 300px;
		}
		.activeField
		{
        background-image: none;
        background-color: #ffffff;
        border: solid 1px #33677F;
		}
		.idle
		{
    border: solid 1px #85b1de;
    background-image: url( 'blue_bg.png' );
    background-repeat: repeat-x;
    background-position: top;
		}

</style>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js" 
		type="text/javascript" charset="utf-8"></script>
	<script>
	$(document).ready(function(){
    $("input, textarea").addClass("idle");
        $("input, textarea").focus(function(){
            $(this).addClass("activeField").removeClass("idle");
    }).blur(function(){
            $(this).removeClass("activeField").addClass("idle");
    });
	});
	</script>
	<script>
		var speed=70;
		var current=0;
		var step=1;
		var headerheight=300;
		var imageheight=4300;
		var start= -(imageheight-headerheight);
		function overlay(){
			current-=step;
			if(current==start)
				current=0;
			$('#header').css("background-position","0 "+current+"px");

		}
		var overlayreturn=setInterval("overlay()",speed)
	</script>
<script src="js/main.js"></script>
<script src="js/ajax.js"></script>
<script>
function login(){
	alert("login");
	var n = _("name").value;
	var p = _("pass").value;
	if(n == "" || p == ""){
		_("status").innerHTML = "Fill out all of the form data";
		alert("empty");
	} else {
	alert("else");
		_("submit").style.display = "none";
		_("status").innerHTML = 'please wait ...';
		var ajax = ajaxObj("POST", "login.php");
		ajax.onreadystatechange = function() {
		    if(ajaxReturn(ajax) == true) {
	            if(ajax.responseText == "login_failed"){
					_("status").innerHTML = "Login unsuccessful, please try again.";
					_("submit").style.display = "block";
				}
				else if(ajax.responseText == "password_wrong"){
					_("status").innerHTML = "Wrong password entered";
					_("submit").style.display = "block";
				}
				else {
					window.location = "complaints.php";
				}
	        }
        }
        ajax.send("n="+n+"&p="+p);
	}
}
</script>

</head>
<body>
	<div id="wrapper">
		<div id="header">
			<div>
			<marquee><h1>Member of Election Commission</h1></marquee>
			</div>
		</div>
	
		<div id="body">
		
		  <h3>Log In Here</h3>
		  <!-- LOGIN FORM -->
		  <form id="inputArea" method="post" action="login.php">
			<div>Member Name:</div>
			<input type="text" id="name" onfocus="emptyElement('status')" maxlength="88">
			<div>Password:</div>
			<input type="password" id="pass" onfocus="emptyElement('status')" maxlength="100">
			<br /><br />
			<input id="submit" type="button" onclick="login()" value="log in"> 
			<p id="status"></p>
		  </form>
		  </div>
		  <!-- LOGIN FORM -->
		
	</div>
</body>
</html>