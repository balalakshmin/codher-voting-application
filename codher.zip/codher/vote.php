<html>
	<head>
		<style>
		#header{
			height:300px;
			background: #000 url('images/background.jpg') repeat-y
				scroll left top;
			text-align: center;
		}
		#header div{
			height:300px;
			width:930px;
			background: transparent url('images/overlay.png') no-repeat
				scroll left top;

		}
		#header h1{
			padding-top: 125px;
			color:white;
			font-family: 'Lucida Console',monospace;

		}
		#nav{
			height:30px;
		}
		
		#body{
			background-color: #e74c3c;
			width:936px;
			height:900px;
		}
		body{
			background-color: black;
		}
		#wrapper{
			margin:0 auto;
			width:920px;
		}
		#inputArea
		{
    font-family: Arial, Sans-Serif;
    font-size: 13px;
    background-color: #d6e5f4;
    padding: 10px;
		}
		#inputArea input, #inputArea textarea
		{
    font-family: Arial, Sans-Serif;
    font-size: 13px;
    margin-bottom: 5px;
    display: block;
    padding: 4px;
    width: 300px;
		}
		.activeField
		{
        background-image: none;
        background-color: #ffffff;
        border: solid 1px #33677F;
		}
		.idle
		{
    border: solid 1px #85b1de;
    background-image: url( 'blue_bg.png' );
    background-repeat: repeat-x;
    background-position: top;
		}

	</style>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js" 
		type="text/javascript" charset="utf-8"></script>
	<script>
	$(document).ready(function(){
    $("input, textarea").addClass("idle");
        $("input, textarea").focus(function(){
            $(this).addClass("activeField").removeClass("idle");
    }).blur(function(){
            $(this).removeClass("activeField").addClass("idle");
    });
	});
	</script>
	<script>
		var speed=70;
		var current=0;
		var step=1;
		var headerheight=300;
		var imageheight=4300;
		var start= -(imageheight-headerheight);
		function overlay(){
			current-=step;
			if(current==start)
				current=0;
			$('#header').css("background-position","0 "+current+"px");

		}
		var overlayreturn=setInterval("overlay()",speed)
	</script>
<head>
<body>
	<div id="wrapper">
		<div id="header">
			<div>
				<h1>Make Voting Corruption free<h1>
			</div>

		</div>
		<div id="nav"></div>
		<div id="body">
			<form id="inputArea">
				<div class="form group">
				<input type="text" id="form-control register-field"/>
				</div>
			</form>
		</div>
	</div>
</body>
</html>
