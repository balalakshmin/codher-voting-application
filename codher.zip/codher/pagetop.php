<div id="pagetop" style="background-image: url('images/header.jpg');width:2000px;height:100px;margin-left:-100px;">
&nbsp;	
</div>